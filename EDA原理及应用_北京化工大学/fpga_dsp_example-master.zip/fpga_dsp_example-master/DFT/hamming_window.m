l=64
w=hamming(l);
wvtool(w);