
N=63;
w1=bartlett(N);
wvtool(w1);