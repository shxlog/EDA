
N=64;
w1=blackman(N);
wvtool(w1);