l=64
w=hann(l);
wvtool(w);