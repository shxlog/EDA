n=50;
w=rectwin(n);
wvtool(w);